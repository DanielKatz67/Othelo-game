﻿namespace Ex02_Othelo
{
    public enum eColor
    {
        White = 'o',
        Black = 'x',
    }
}
