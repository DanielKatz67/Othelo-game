﻿namespace Ex02_Othelo
{
    public class Program
    {
        public static void Main()
        {
            OtheloGame otheloGame = new OtheloGame();
            otheloGame.Run();
        }
    }
}
